"""
This module implements a factory manager for the SCM league of ANAC 2019 competition.

To start working on it, you need to do the following:

    1. Update the fields in this docstring with the information from your project (e.g. agent name, team name, etc)
    2. Update the name of this file from ``myagent.py`` to ``your-agent-name.py``
    3. Rename the folder in which this file is located from ``myagent`` to ``your-agent-name``
    4. Rename the single class in this file form ``MyAgent`` to ``YourAgentName``. Please follow standard python naming
       conventions
    5. Change the implementation of whatever functions you need in the provided factory manager
    6. Modify the name of either ``../report/myagent.tex`` or ``../report/myagent.docx`` to
       ``../report/your-agent-name.tex`` or ``../report/your-agent-name.docx`` as appropriate and use it to write your
       report. Remember to convert your report to ``pdf`` format before submission.
    7. Develop your agent by overriding one or more functions of the provided agent and test it.
       Running this file directly will call main() which runs a small tournament between your agent and the built-in
       greedy factory manager.
    8. After developing your agent, zip ``your-agent-name`` folder into ``your-team-name_your-agent-name.zip`` and
       submit it along with ``your-agent-name.pdf`` (after generating it from the tex or docx file). These are the
       two files that need to be submitted.

Agent Information
=================

  - Agent Name: my-agent-name
  - Team Name: my-team-name
  - Contact Email: my-email@some-server.xyz
  - Affiliation: Institute, Department
  - Country: country-name
  - Team Members:
    1. First Name <first.email@institute.xyz>
    2. Second Name <first.email@institute.xyz>
    .
    .
    n. Last Name <first.email@institute.xyz>

"""
import time

from negmas import Contract, Breach, RenegotiationRequest, NegotiatorProxy, MechanismProxy, MechanismInfo
from negmas import MechanismState
from negmas.apps.scml import DoNothingFactoryManager, Loan, ProductionFailure, CFP, GreedyFactoryManager
from negmas.apps.scml.utils import anac2019_tournament
from negmas.helpers import humanize_time
from tabulate import tabulate
from typing import Optional, List, Dict, Any


class MyAgent(DoNothingFactoryManager):
    """
    This is the only class you *need* to implement. The current skeleton has a basic do-nothing implementation.
    You can modify any parts of it as you need. You can act in the world by calling methods in the agent-world-interface
    instantiated as `self.awi` in your agent. See the documentation for more details.
    This is a basic agents with some of the advanced callbacks being implemented by simply doing nothing.

    """

    # =====================
    # Time-Driven Callbacks
    # =====================

    def init(self):
        """Called to initialize the agent **after** the world is initialized. the AWI is accessible at this point.

        Remarks:

            - You **MUST** call super() here before doing anything else.

        """
        super().init()

    def step(self):
        """Called at every production step by the world

        Remarks:

            - You **SHOULD** call super() here before doing anything else.

        """
        super().step()

    # ==========================
    # Important Events Callbacks
    # ==========================

    def on_new_cfp(self, cfp: CFP) -> None:
        """Called when a new CFP for a product for which the agent registered interest is published"""

    def on_remove_cfp(self, cfp: CFP) -> None:
        """Called when a new CFP for a product for which the agent registered interest is removed"""

    # ================================
    # Negotiation Control and Feedback
    # ================================

    def on_negotiation_request(self, cfp: "CFP", partner: str) -> Optional[NegotiatorProxy]:
        """Called whenever someone (partner) is requesting a negotiation with the agent about a Call-For-Proposals
        (cfp) that was earlier published by this agent to the bulletin-board

        Returning `None` means rejecting to enter this negotiation

        """
        pass

    def on_negotiation_failure(self, partners: List[str], annotation: Dict[str, Any], mechanism: MechanismInfo
                               , state: MechanismState) -> None:
        """Called whenever a negotiation ends without agreement

        Remarks:

            - You **MUST** call super() here before doing anything else.

        """
        super().on_negotiation_failure(partners=partners, annotation=annotation, mechanism=mechanism, state=state)

    def on_negotiation_success(self, contract: Contract, mechanism: MechanismInfo) -> None:
        """Called whenever a negotiation ends with agreement

        Remarks:

            - You **MUST** call super() here before doing anything else.

        """
        super().on_negotiation_success(contract=contract, mechanism=mechanism)

    # =============================
    # Contract Control and Feedback
    # =============================

    def sign_contract(self, contract: Contract) -> Optional[str]:
        """Called after the signing delay from contract conclusion to sign the contract. Contracts become binding
        only after they are signed.

        Remarks:

            - Return `None` if you decided not to sign the contract. Return your ID (self.id) otherwise.

        """
        return self.id

    def on_contract_signed(self, contract: Contract) -> None:
        """Called whenever a contract is signed by all partners

        Remarks:

            - You **MUST** call super() here before doing anything else.

        """
        super().on_contract_signed(contract=contract)

def main(reveal_names=True, n_steps=5, max_n_runs=2, n_runs_per_config=1):
    """Not needed for submission. You can just use this function to run a fast check of your agent

    :param reveal_names: If true, agent names will reveal their types. This will be false in the actual competition
    :param n_steps: The number of simulation steps.
    :param max_n_runs: The number of different configs to use
    :param n_runs_per_config: The number of runs for every config.
    :return: None
    """
    start = time.perf_counter()
    results = anac2019_tournament(competitors=[MyAgent, GreedyFactoryManager], agent_names_reveal_type=reveal_names
                                  , verbose=True, n_steps=n_steps, max_n_runs=max_n_runs
                                  , n_runs_per_config=n_runs_per_config)
    print(tabulate(results.total_scores, headers='keys', tablefmt='psql'))
    print(f'Finished in {humanize_time(time.perf_counter() - start)}')


if __name__ == '__main__':
    """Will be called if you run this file directly"""
    main()
