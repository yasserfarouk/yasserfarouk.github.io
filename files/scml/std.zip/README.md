This is the skeleton for developing an agent for SCML 2021 (Standard or Collusion tracks).
You will find two folders:

* **std_components** For developing a components based agent as described
  [here](http://www.yasserm.com/scml/scml2020docs/tutorials/03.develop_agent_scml2020.html#agent-anatomy)
* **std_monolithic** For developing a monolithic agent as described 
  [here](http://www.yasserm.com/scml/scml2020docs/tutorials/03.develop_agent_scml2020.html#an-agent-from-scratch)

You can safely delete the folder you are not going to use.

