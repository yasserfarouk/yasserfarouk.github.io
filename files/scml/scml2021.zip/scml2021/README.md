SCML 2021 Agent Skeleton
========================

This skeleton contains the following folders:

1. oneshot: A full skeleton for an agent compatible with the OneShot track. 
   This agent will also run in the standard and collusion tracks.
2. std_monolethic: A full skeleton for an agent compatible with the standard/
   collusion tracks built by implementing callback directly with no decomposition.
   This agent is NOT compatible with the OneShot track
2. std_components: A full skeleton for an agent compatible with the standard/
   collusion tracks built using the decomposition into trading, negotiation and 
   production strategies. This agent is NOT compatible with the OneShot track
