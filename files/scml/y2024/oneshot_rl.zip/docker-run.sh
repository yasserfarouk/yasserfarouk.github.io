#!/bin/sh

docker compose run --service-ports scml $@
