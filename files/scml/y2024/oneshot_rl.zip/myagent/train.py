# trains an RL model
#
import logging
import sys

# from pathlib import Path
from typing import Any

from rich import print
from scml.oneshot.rl.action import UnconstrainedActionManager
from scml.oneshot.rl.agent import OneShotRLAgent
from scml.oneshot.rl.common import model_wrapper
from scml.oneshot.rl.env import OneShotEnv

# sys.path.append(str(Path(__file__).parent))
from .common import MODEL_PATH, MyObservationManager, TrainingAlgorithm, make_context

NTRAINING = 100  # number of training steps


def make_env(train_as_supplier, log: bool = False) -> OneShotEnv:
    log_params: dict[str, Any] = (
        dict(
            no_logs=False,
            log_stats_every=1,
            log_file_level=logging.DEBUG,
            log_screen_level=logging.ERROR,
            save_signed_contracts=True,
            save_cancelled_contracts=True,
            save_negotiations=True,
            save_resolved_breaches=True,
            save_unresolved_breaches=True,
            debug=True,
        )
        if log
        else dict(debug=True)
    )
    log_params.update(
        dict(
            ignore_agent_exceptions=False,
            ignore_negotiation_exceptions=False,
            ignore_contract_execution_exceptions=False,
            ignore_simulation_exceptions=False,
        )
    )
    context = make_context(train_as_supplier)
    return OneShotEnv(
        action_manager=UnconstrainedActionManager(context=context),
        observation_manager=MyObservationManager(context=context),
        context=context,
        extra_checks=False,
    )


def try_a_model(
    model,
    as_supplier: bool,
):
    """Runs a single simulation with one agent controlled with the given model"""

    obs_type = MyObservationManager
    # Create a world context compatibly with the model
    context = make_context(as_supplier)
    # sample a world and the RL agents (always one in this case)
    world, _ = context.generate(
        types=(OneShotRLAgent,),
        params=(
            dict(
                models=[model_wrapper(model)],
                observation_managers=[obs_type(context)],
            ),
        ),
    )
    # run the world simulation
    world.run_with_progress()
    return world


if __name__ == "__main__":
    # choose the type of the model. Possibilities supported are:
    # fixed: Supports a single world configuration
    # limited: Supports a limited range of world configuration
    # unlimited: Supports any range of world configurations
    type_ = "limited" if len(sys.argv) < 2 else sys.argv[1]

    for as_supplier in (False, True):
        print(f"Training as {'supplier' if as_supplier else 'consumer'}")
        # create a gymnasium environment for training
        env = make_env(as_supplier)

        # choose a training algorithm
        model = TrainingAlgorithm(  # type: ignore learning_rate must be passed by the algorithm itself
            "MlpPolicy", env, verbose=0
        )

        # train the model
        model.learn(total_timesteps=NTRAINING, progress_bar=True)
        print(
            f"\tFinished training the model for {NTRAINING} steps ... Testing it on a single world simulation"
        )

        # decide the model path to save to
        model_path = (
            MODEL_PATH.parent
            / f"{MODEL_PATH.name}{'_supplier' if as_supplier else '_consumer'}"
        )

        # save the model
        model.save(model_path)
        # remove the in-memory model
        del model
        # load the model
        model = TrainingAlgorithm.load(model_path)
        # try the model in a single simulation
        world = try_a_model(model, as_supplier)
        print(world.scores())
