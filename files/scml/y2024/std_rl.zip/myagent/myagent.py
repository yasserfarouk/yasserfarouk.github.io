"""
**Submitted to ANAC 2024 SCML (OneShot track)**
*Team* type your team name here
*Authors* type your team member names with their emails here

This code is free to use or update given that proper attribution is given to
the authors and the ANAC 2024 SCML competition.
"""

from scml.oneshot.rl.common import model_wrapper
from scml.std.rl.agent import StdRLAgent

from .common import (MODEL_PATH, MyObservationManager, TrainingAlgorithm,
                     make_context)

# used to repeat the response to every negotiator.


class MyAgent(StdRLAgent):
    """
    This is the only class you *need* to implement. The current skeleton simply loads a single model
    that is supposed to be saved in MODEL_PATH (train.py can be used to train such a model).
    """

    def __init__(self, *args, **kwargs):
        # get full path to models (supplier and consumer models).
        base_name = MODEL_PATH.name
        paths = [_ for _ in MODEL_PATH.glob("*.zip")]
        # update keyword arguments
        kwargs.update(
            dict(
                # load models from MODEL_PATH
                models=tuple(model_wrapper(TrainingAlgorithm.load(_)) for _ in paths),
                # create corresponding observation managers
                observation_managers=tuple(
                    MyObservationManager(
                        context=make_context(level=int(_.name.split("_")[-1]))
                    )
                    for _ in paths
                ),
            )
        )
        # Initialize the base OneShotRLAgent with model paths and observation managers.
        super().__init__(*args, **kwargs)


if __name__ == "__main__":
    from .helpers.runner import run

    run([MyAgent])
