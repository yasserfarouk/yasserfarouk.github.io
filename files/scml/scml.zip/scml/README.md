===================
SCML Agent Skeleton
===================

This skeleton contains the following folders:

1. python: You can modify one of the two provided files for your submission in python. *basic.py* is a basic agent that implements
   the most necessary callbacks of a factory manager. *advanced.py* is a more advanced skeleton with all important
   callbacks. Both agents are doing nothing. You can override whichever of them you like. Moreover, you can change
   either of them to inherit from the `GreedyFactoryManager` instead of the `DoNothingManager` if you want to reuse some
   of the functionality implemented in the `GreedyFactoryManager`.
2. java: You can modify one of the two provided files for your submission in java. *basic.java* is a basic agent that implements
   the most necessary callbacks of a factory manager. *advanced.java* is a more advanced skeleton with all important
   callbacks. Both agents are doing nothing. You can override whichever of them you like. Moreover, you can change
   either of them to inherit from the `GreedyFactoryManager` instead of the `DoNothingManager` if you want to reuse some
   of the functionality implemented in the `GreedyFactoryManager`.
3. report: A folder with empty latex and docx files that you can use to write your 2-pages report. Please remember to 
   submit a `pdf` version of the report.
   
To develop your agent, the only required steps are the following:

1. [required] Follow the installation instructions of your language as described in [Python Documentation](http://negmas.readthedocs.io)
   or [Java Documentation](http://jnegmas.readthedocs.io).
2. [recommended] Change the name of the agent class from `MyAgent' to your-agent-name.
3. Change the implementation of whatever functions you need in the provided factory manager
4. [recommended] Modify the name of either ``../report/myagent.tex`` or ``../report/myagent.docx`` to
   ``../report/your-agent-name.tex`` or ``../report/your-agent-name.docx`` as appropriate and use it to write your
   report.
5. [recommended] You can run a simple tournament of your agent against the default `GreedyFactoryManager` using `negmas tournamet` 
   command
6. [required] After developing your agent, zip ``your-agent-name`` folder into ``your-team-name_your-agent-name.zip`` and
   submit it along with ``your-agent-name.pdf`` (after generating it from the tex or docx file). These are the
   two files that need to be submitted.

Agent Information
-----------------

  - Agent Name: my-agent-name
  - Team Name: my-team-name
  - Contact Email: my-email@some-server.xyz
  - Affiliation: Institute, Department
  - Country: country-name
  - Team Members:
    1. First Name <first.email@institute.xyz>
    2. Second Name <first.email@institute.xyz>
    .
    .
    n. Last Name <first.email@institute.xyz>
