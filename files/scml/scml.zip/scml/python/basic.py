"""
This module implements a factory manager for the SCM league of ANAC 2019 competition. This basic version has what we
consider as the most important callbacks. Please refer to the [http://www.yasserm.com/scml/scml.pdf](game description)
for all the callbacks.

Your agent can learn about the state of the world and itself by accessing properties in the AWI it has. For example::

self.awi.n_steps  # gives the number of simulation steps

You can access the state of your factory as::

self.awi.state

Your agent can act in the world by calling methods in the AWI it has. For example:

>>> self.awi.register_cfp(cfp)  # registers a new CFP

You can access the full list of these capabilities on the documentation.

- For properties/methods available only to SCM agents, check the list here:
https://negmas.readthedocs.io/en/latest/api/negmas.apps.scml.SCMLAWI.html

- For properties/methods available to all kinds of agents in all kinds of worlds, check the list here:
https://negmas.readthedocs.io/en/latest/api/negmas.situated.AgentWorldInterface.html

The SCMLAgent class itself has some helper properties/methods that internally call the AWI. These include:

- request_negotiation(): Generates a unique identifier for this negotiation request and passes it to the AWI through a
                         call of awi.request_negotiation(). It is recommended to use this method always to request
                         negotiations. This way, you can access internal lists of requested_negotiations, and
                         running_negotiations. If on the other hand you use awi.request_negotiation(), these internal
                         lists will not be updated and you will have to keep track to requested and running negotiations
                         manually if you need to use them.
- can_expect_agreement(): Checks if it is possible in principle to get an agreement on this CFP by the time it becomes
                          executable
- products, processes: shortcuts to awi.products and awi.processes


"""
import time

from negmas import Contract, Negotiator
from negmas.apps.scml import DoNothingFactoryManager, CFP, GreedyFactoryManager
from negmas.apps.scml.utils import anac2019_std, anac2019_collusion
from negmas.helpers import humanize_time
from tabulate import tabulate
from typing import Optional


class MyAgent(DoNothingFactoryManager):
    """
    This is the only class you *need* to implement. The current skeleton has a basic do-nothing implementation.
    You can modify any parts of it as you need. You can act in the world by calling methods in the agent-world-interface
    instantiated as `self.awi` in your agent. See the documentation for more details.

    """

    # =====================
    # Time-Driven Callbacks
    # =====================

    def init(self):
        """Called to initialize the agent **after** the world is initialized. the AWI is accessible at this point."""

    def step(self):
        """Called at every production step by the world"""

    # ==========================
    # Important Events Callbacks
    # ==========================

    def on_new_cfp(self, cfp: CFP) -> None:
        """Called when a new CFP for a product for which the agent registered interest is published"""

    # ================================
    # Negotiation Control and Feedback
    # ================================

    def respond_to_negotiation_request(self, cfp: "CFP", partner: str) -> Optional[Negotiator]:
        """Called whenever someone (partner) is requesting a negotiation with the agent about a Call-For-Proposals
        (cfp) that was earlier published by this agent to the bulletin-board

        Returning `None` means rejecting to enter this negotiation

        """

    # =============================
    # Contract Control and Feedback
    # =============================

    def on_contract_signed(self, contract: Contract) -> None:
        """Called whenever a contract is signed by all partners"""


def main(competition='std', reveal_names=True, n_steps=20, n_configs=2, max_n_worlds_per_config=10, n_runs_per_world=1):
    """
    **Not needed for submission.** You can use this function to test your agent.

    Args:
        competition: The competition type to run (possibilities are std, collusion and sabotage).
        reveal_names: If true, agent names will reveal their types. This will be false in the actual competition
        n_steps: The number of simulation steps.
        n_configs: Number of different world configurations to try. Different world configurations will correspond to
                   different number of factories, profiles, production graphs etc
        max_n_worlds_per_config: How many manager-factory assignments are allowed for each generated configuration. The
                                 system will sample this number of worlds (at most) from all possible permutations of
                                 manager-factory assignments. Notice that if your competition is set to 'std', only two
                                 worlds will be generated per configuration at most
        n_runs_per_world: How many times will each world be run.

    Returns:
        None

    Remarks:

        - This function will take several minutes to run.
        - To speed it up, use a smaller `n_step` value
        - Please notice that the greedy factory manager (the default agent that always exists in the world), will lose
          in the beginning of the simulation (in most cases). To get a better understanding of your agent's performance
          set `n_step` to a value of at least 100. The actual league will use 200 steps.

    """
    start = time.perf_counter()
    if competition == 'std':
        results = anac2019_std(competitors=[MyAgent, GreedyFactoryManager], agent_names_reveal_type=reveal_names
                               , verbose=True, n_steps=n_steps, n_configs=n_configs
                               , max_worlds_per_config=max_n_worlds_per_config, n_runs_per_world=n_runs_per_world)
    elif competition == 'collusion':
        results = anac2019_collusion(competitors=[MyAgent, GreedyFactoryManager], agent_names_reveal_type=reveal_names
                                     , verbose=True, n_steps=n_steps, n_configs=n_configs
                                     , max_worlds_per_config=max_n_worlds_per_config, n_runs_per_world=n_runs_per_world)
    elif competition == 'sabotage':
        print('The sabotage competition will be run by comparing the score of all other agents with and without '
              'the agent being tested. The exact way this is to be done is left for the organization committee to '
              'decide')
        return
    else:
        raise ValueError(f'Unknown competition type {competition}')
    print(tabulate(results.total_scores, headers='keys', tablefmt='psql'))
    print(f'Finished in {humanize_time(time.perf_counter() - start)}')


if __name__ == '__main__':
    """Will be called if you run this file directly"""
    main()
