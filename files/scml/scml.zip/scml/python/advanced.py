"""
This module implements a factory manager for the SCM league of ANAC 2019 competition. This advanced version has all
callbacks. Please refer to the [http://www.yasserm.com/scml/scml.pdf](game description)
for all the callbacks.

Your agent can learn about the state of the world and itself by accessing properties in the AWI it has. For example::

self.awi.n_steps  # gives the number of simulation steps

You can access the state of your factory as::

self.awi.state

Your agent can act in the world by calling methods in the AWI it has. For example:

>>> self.awi.register_cfp(cfp)  # registers a new CFP

You can access the full list of these capabilities on the documentation.

- For properties/methods available only to SCM agents, check the list here:
https://negmas.readthedocs.io/en/latest/api/negmas.apps.scml.SCMLAWI.html

- For properties/methods available to all kinds of agents in all kinds of worlds, check the list here:
https://negmas.readthedocs.io/en/latest/api/negmas.situated.AgentWorldInterface.html

The SCMLAgent class itself has some helper properties/methods that internally call the AWI. These include:

- request_negotiation(): Generates a unique identifier for this negotiation request and passes it to the AWI through a
                         call of awi.request_negotiation(). It is recommended to use this method always to request
                         negotiations. This way, you can access internal lists of requested_negotiations, and
                         running_negotiations. If on the other hand you use awi.request_negotiation(), these internal
                         lists will not be updated and you will have to keep track to requested and running negotiations
                         manually if you need to use them.
- can_expect_agreement(): Checks if it is possible in principle to get an agreement on this CFP by the time it becomes
                          executable
- products, processes: shortcuts to awi.products and awi.processes
"""
import time

from negmas import Contract, Breach, RenegotiationRequest, Negotiator, AgentMechanismInterface
from negmas import MechanismState
from negmas.apps.scml import FactoryManager, Loan, ProductionFailure, CFP, GreedyFactoryManager, FinancialReport, \
    ProductionReport
from negmas.apps.scml.utils import anac2019_std, anac2019_collusion
from negmas.helpers import humanize_time
from tabulate import tabulate
from typing import Optional, List, Dict, Any


class MyAgent(FactoryManager):
    """
    This is the only class you *need* to implement. The current skeleton has a basic do-nothing implementation.
    You can modify any parts of it as you need. You can act in the world by calling methods in the agent-world-interface
    instantiated as `self.awi` in your agent. See the documentation for more details

    """

    # =====================
    # Time-Driven Callbacks
    # =====================

    def init(self):
        """Called once after the agent-world interface is initialized"""
        pass

    def step(self):
        """Called at every production step by the world"""

    # ==========================
    # Important Events Callbacks
    # ==========================

    def on_new_cfp(self, cfp: CFP) -> None:
        """Called when a new CFP for a product for which the agent registered interest is published"""

    def on_remove_cfp(self, cfp: CFP) -> None:
        """Called when a new CFP for a product for which the agent registered interest is removed"""

    # ====================
    # Production Callbacks
    # ====================

    def on_production_failure(self, failures: List[ProductionFailure]) -> None:
        """Will be called whenever a failure happens in one of the agent's factory's production lines"""

    def on_production_success(self, reports: List[ProductionReport]) -> None:
        """Will be called whenever some production succeeds in the factory owned by the manager"""

    def on_inventory_change(self, product: int, quantity: int, cause: str) -> None:
        """Will be called whenever there is a change in inventory for a cause other than production (e.g. contract
        execution)."""

    def on_cash_transfer(self, amount: float, cause: str) -> None:
        """Called whenever there is a cash transfer to or from the agent"""

    # ================================
    # Negotiation Control and Feedback
    # ================================

    def respond_to_negotiation_request(self, cfp: "CFP", partner: str) -> Optional[Negotiator]:
        """Called whenever someone (partner) is requesting a negotiation with the agent about a Call-For-Proposals
        (cfp) that was earlier published by this agent to the bulletin-board

        Returning `None` means rejecting to enter this negotiation

        """

    def on_neg_request_rejected(self, req_id: str, by: Optional[List[str]]):
        """Called when a negotiation request sent by this agent is rejected. The ``req_id`` is a unique identifier
        for this negotiation request.

        Remarks:

            - You **MUST** call super() here before doing anything else.

        """

    def on_neg_request_accepted(self, req_id: str, mechanism: AgentMechanismInterface):
        """Called when a requested negotiation is accepted. The ``req_id`` is a unique identifier for this negotiation
        request."""
        super().on_neg_request_accepted(req_id=req_id, mechanism=mechanism)

    def on_negotiation_failure(self, partners: List[str], annotation: Dict[str, Any], mechanism: AgentMechanismInterface
                               , state: MechanismState) -> None:
        """Called whenever a negotiation ends without agreement"""

    def on_negotiation_success(self, contract: Contract, mechanism: AgentMechanismInterface) -> None:
        """Called whenever a negotiation ends with agreement"""

    # =============================
    # Contract Control and Feedback
    # =============================

    def sign_contract(self, contract: Contract) -> Optional[str]:
        """Called after the signing delay from contract conclusion to sign the contract. Contracts become binding
        only after they are signed.

        Remarks:

            - Return `None` if you decided not to sign the contract. Return your ID (self.id) otherwise.

        """
        return self.id

    def on_contract_signed(self, contract: Contract) -> None:
        """Called whenever a contract is signed by all partners"""

    def on_contract_cancelled(self, contract: Contract, rejectors: List[str]) -> None:
        """Called whenever at least a partner did not sign the contract"""

    def on_contract_nullified(self, contract: Contract, bankrupt_partner: str, compensation: float) -> None:
        """Will be called whenever a contract the agent is involved in is nullified because another partner went
        bankrupt"""

    def on_contract_executed(self, contract: Contract) -> None:
        """Called whenever a contract is fully executed without any breaches"""

    def on_contract_breached(
        self, contract: Contract, breaches: List[Breach], resolution: Optional[Contract]
    ) -> None:
        """Called after full processing of contracts that were breached.

        Args:

            contract: The contract breached
            breaches: A list of all breaches committed
            resolution: If not None, the resolution contract resulting from re-negotiation (if any).

        Remarks:

            - Even if renegotiation resulted in an agreement, this callback will be called.

        """

    def confirm_contract_execution(self, contract: Contract) -> bool:
        """Called at the delivery time specified in the contract to confirm that the agent wants to execute it.

        Returning False is equivalent to committing a `refusal-to-execute` breach of maximum level (1.0).

        """

    def confirm_partial_execution(self, contract: Contract, breaches: List[Breach]) -> bool:
        """Will be called whenever a contract cannot be fully executed due to breaches by the other partner.

        Will not be called if both partners committed breaches.
        """

    # ====================================
    # Re-negotiations when breaches happen
    # ====================================

    def set_renegotiation_agenda(self, contract: Contract, breaches: List[Breach]) -> Optional[RenegotiationRequest]:
        """Will be called when a contract fails to be concluded due to any kind of breach to allow partners to start
        a re-negotiation that may lead to a new contract that nullifies these breaches. It is always called on agents
        in descending order of their total breach levels on this contract.

        Returning `None` will mean that you pass your opportunity to set the renegotiation agenda.

        """

    def respond_to_renegotiation_request(self, contract: Contract, breaches: List[Breach],
                                         agenda: RenegotiationRequest) -> Optional[Negotiator]:
        """Will be called whenever a renegotiation agenda is set by one agent after a breach asking the other agent to
        join the re-negotiation.

        Returning None means that you refuse to renegotiate.

        """

    # ===================================
    # Loans, Financial issues and Banking
    # ===================================

    def confirm_loan(self, loan: Loan, bankrupt_if_rejected: bool) -> bool:
        """Will be called whenever the agent needs to pay for something (e.g. loan interest, products it bought) but
        does not have enough money in its wallet.

        Args:

            loan: The loan information
            bankrupt_if_rejected: If this is true, rejecting the loan will declare the agent bankrupt.

        Remarks:

            - will NEVER be called in ANAC 2019 League. The bank is disabled and no loans are allowed.

        """

    def on_agent_bankrupt(self, agent_id: str) -> None:
        """
        Will be called whenever any agent goes bankrupt

        Args:

            agent_id: The ID of the agent that went bankrupt

        Remarks:

            - Agents can go bankrupt in two cases:

                1. Failing to pay one installments of a loan they bought and refusing (or being unable to) get another
                   loan to pay it.
                2. Failing to pay a penalty on a sell contract they failed to honor (and refusing or being unable to get
                   a loan to pay for it).

            - The first bankruptcy case above *will never happen* in ANAC 2019 league as the bank is disabled.
            - The second bankruptcy case above *may still happen* in ANAC 2019 league.
            - All built-in agents ignore this call and they use the bankruptcy list ONLY to decide whether or not to
              negotiate in their `on_new_cfp` and `respond_to_negotiation_request` callbacks by pulling the
              bulletin-board using the helper function `is_bankrupt` of their AWI.
        """

    def on_new_report(self, report: FinancialReport):
        """Called whenever a financial report is published.

        Args:

            report: The financial report giving details of the standing of an agent at some time (see `FinancialReport`)

        Remarks:

            - Agents must opt-in to receive these calls by calling `receive_financial_reports` on their AWI
        """


def main(competition='std', reveal_names=True, n_steps=20, n_configs=2, max_n_worlds_per_config=10, n_runs_per_world=1):
    """
    **Not needed for submission.** You can use this function to test your agent.

    Args:
        competition: The competition type to run (possibilities are std, collusion and sabotage).
        reveal_names: If true, agent names will reveal their types. This will be false in the actual competition
        n_steps: The number of simulation steps.
        n_configs: Number of different world configurations to try. Different world configurations will correspond to
                   different number of factories, profiles, production graphs etc
        max_n_worlds_per_config: How many manager-factory assignments are allowed for each generated configuration. The
                                 system will sample this number of worlds (at most) from all possible permutations of
                                 manager-factory assignments. Notice that if your competition is set to 'std', only two
                                 worlds will be generated per configuration at most
        n_runs_per_world: How many times will each world be run.

    Returns:
        None

    Remarks:

        - This function will take several minutes to run.
        - To speed it up, use a smaller `n_step` value
        - Please notice that the greedy factory manager (the default agent that always exists in the world), will lose
          in the beginning of the simulation (in most cases). To get a better understanding of your agent's performance
          set `n_step` to a value of at least 100. The actual league will use 200 steps.

    """
    start = time.perf_counter()
    if competition == 'std':
        results = anac2019_std(competitors=[MyAgent, GreedyFactoryManager], agent_names_reveal_type=reveal_names
                               , verbose=True, n_steps=n_steps, n_configs=n_configs
                               , max_worlds_per_config=max_n_worlds_per_config, n_runs_per_world=n_runs_per_world)
    elif competition == 'collusion':
        results = anac2019_collusion(competitors=[MyAgent, GreedyFactoryManager], agent_names_reveal_type=reveal_names
                                     , verbose=True, n_steps=n_steps, n_configs=n_configs
                                     , max_worlds_per_config=max_n_worlds_per_config, n_runs_per_world=n_runs_per_world)
    elif competition == 'sabotage':
        print('The sabotage competition will be run by comparing the score of all other agents with and without '
              'the agent being tested. The exact way this is to be done is left for the organization committee to '
              'decide')
        return
    else:
        raise ValueError(f'Unknown competition type {competition}')
    print(tabulate(results.total_scores, headers='keys', tablefmt='psql'))
    print(f'Finished in {humanize_time(time.perf_counter() - start)}')


if __name__ == '__main__':
    """Will be called if you run this file directly"""
    main()
