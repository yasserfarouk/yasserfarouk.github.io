/**
This module implements a factory manager for the SCM league of ANAC 2019 competition. This basic version has what we
consider as the most important callbacks. Please refer to the [http://www.yasserm.com/scml/scml.pdf](game description)
for all the callbacks.

Your agent can learn about the state of the world and itself by accessing properties in the AWI it has. For example::

this.awi.getCurrentStep()  // gives the number of simulation steps

You can access the state of your factory as::

this.awi.getState()

Your agent can act in the world by calling methods in the AWI it has. For example:

>>> this.awi.registerCFP(cfp)  // registers a new CFP

You can access the full list of these capabilities on the documentation.

- For properties/methods available only to SCM agents, check the list here:
https://static.javadoc.io/com.yasserm/jnegmas/0.2.0/jnegmas/apps/scml/awi/PythonSCMLAWI.html

- For properties/methods available to all kinds of agents in all kinds of worlds, check the list here:
https://static.javadoc.io/com.yasserm/jnegmas/0.2.0/jnegmas/situated/PythonAgentWorldInterface.html

The SCMLAgent class itself has some helper properties/methods that internally call the AWI. These include:

- requestNegotiation(): Generates a unique identifier for this negotiation request and passes it to the AWI through a
                         call of awi.requestNegotiation(). It is recommended to use this method always to request
                         negotiations. This way, you can access internal lists of requestedNegotiations, and
                         runningNegotiations. If on the other hand you use awi.requestNegotiation(), these internal
                         lists will not be updated and you will have to keep track to requested and running negotiations
                         manually if you need to use them.
*/
package com.team;
import jnegmas.apps.scml.common.CFP;
import jnegmas.apps.scml.factory_managers.DoNothingFactoryManager;
import jnegmas.sao.SAONegotiator;
import jnegmas.situated.Contract;

/**
 * You need to override whatever functions in the DoNothingFactoryManager that help you win
 */
public class MyFactoryManager extends DoNothingFactoryManager{

    /**
     * Called to initialize the agent the awi is usable here.
     */
    @Override
    public void init() {
        super.init();
    }

    /**
     * Called at every simulation step.
     */
    @Override
    public void step() {
        super.step();
    }

    /**
     * Called whenever a CFP is published for which the agent has previously registered interest.
     *
     * @param cfp The CFP
     */
    @Override
    public void onNewCFP(CFP cfp) {
        super.onNewCFP(cfp);
    }

    /**
     * Called when another agents requests a negotiation with this agent based on a CFP published by this agent.
     *
     * @param cfp The CFP published by the agent
     * @param partner The other agent requesting to negotiate
     * @return Null to reject the offer or a Negotiator to accept it.
     */
    @Override
    public SAONegotiator respondToNegotiationRequest(CFP cfp, String partner) {
        return super.respondToNegotiationRequest(cfp, partner);
    }

    /**
     * Called after a contract is signed for which one of the parties is this agent.
     *
     * @param contract The contract
     */
    @Override
    public void onContractSigned(Contract contract) {
        super.onContractSigned(contract);
    }
}
