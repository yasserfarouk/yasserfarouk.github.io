#!/usr/bin/env python
"""
**Submitted to ANAC 2023 SCML (OneShot track)**
*Authors* type-your-team-member-names-with-their-emails here

This code is free to use or update given that proper attribution is given to
the authors and the ANAC 2023 SCML.
"""
from __future__ import annotations

# used to repeat the response to every negotiator.
import itertools

# required for running tournaments and printing
import time

# required for typing
from typing import Any

from negmas.helpers import humanize_time
from negmas.sao import SAOResponse, SAOState

# required for development
from scml.oneshot import OneShotAgent, OneShotAWI
from scml.oneshot.agents import RandomOneShotAgent, SyncRandomOneShotAgent
from scml.scml2020.utils import anac2023_collusion, anac2023_oneshot, anac2023_std
from tabulate import tabulate

from negmas import Contract, Outcome, ResponseType, SAOState


class MyAgent(OneShotAgent):
    """
    This is the only class you *need* to implement. The current skeleton has a
    basic do-nothing implementation.
    You can modify any parts of it as you need. You can act in the world by
    calling methods in the agent-world-interface instantiated as `self.awi`
    in your agent. See the documentation for more details


    **Please change the name of this class to match your agent name**

    """

    # =====================
    # Negotiation Callbacks
    # =====================

    def propose(self, negotiator_id: str, state: SAOState) -> Outcome | None:
        """Called when the agent is asking to propose in one negotiation"""
        pass

    def respond(
        self, negotiator_id: str, state: SAOState, offer: Outcome
    ) -> ResponseType:
        """Called when the agent is asked to respond to an offer"""
        return ResponseType.END_NEGOTIATION

    # =====================
    # Time-Driven Callbacks
    # =====================

    def init(self):
        """Called once after the agent-world interface is initialized"""
        pass

    def before_step(self):
        """Called at at the BEGINNING of every production step (day)"""

    def step(self):
        """Called at at the END of every production step (day)"""

    # ================================
    # Negotiation Control and Feedback
    # ================================

    def on_negotiation_failure(
        self,
        partners: list[str],
        annotation: dict[str, Any],
        mechanism: OneShotAWI,
        state: SAOState,
    ) -> None:
        """Called when a negotiation the agent is a party of ends without
        agreement"""

    def on_negotiation_success(self, contract: Contract, mechanism: OneShotAWI) -> None:
        """Called when a negotiation the agent is a party of ends with
        agreement"""


def run(
    competition="oneshot",
    reveal_names=True,
    n_steps=10,
    n_configs=2,
):
    """
    **Not needed for submission.** You can use this function to test your agent.

    Args:
        competition: The competition type to run (possibilities are oneshot, std,
                     collusion).
        n_steps:     The number of simulation steps.
        n_configs:   Number of different world configurations to try.
                     Different world configurations will correspond to
                     different number of factories, profiles
                     , production graphs etc

    Returns:
        None

    Remarks:

        - This function will take several minutes to run.
        - To speed it up, use a smaller `n_step` value

    """
    if competition == "oneshot":
        competitors = [MyAgent, RandomOneShotAgent, SyncRandomOneShotAgent]
    else:
        from scml.scml2020.agents import BuyCheapSellExpensiveAgent, DecentralizingAgent

        competitors = [
            MyAgent,
            DecentralizingAgent,
            BuyCheapSellExpensiveAgent,
        ]

    start = time.perf_counter()
    if competition == "std":
        runner = anac2023_std
    elif competition == "collusion":
        runner = anac2023_collusion
    else:
        runner = anac2023_oneshot
    results = runner(
        competitors=competitors,
        verbose=True,
        n_steps=n_steps,
        n_configs=n_configs,
    )
    # just make names shorter
    results.total_scores.agent_type = results.total_scores.agent_type.str.split(  # type: ignore
        "."
    ).str[
        -1
    ]
    # display results
    print(tabulate(results.total_scores, headers="keys", tablefmt="psql"))  # type: ignore
    print(f"Finished in {humanize_time(time.perf_counter() - start)}")


if __name__ == "__main__":
    import sys

    run(sys.argv[1] if len(sys.argv) > 1 else "oneshot")
