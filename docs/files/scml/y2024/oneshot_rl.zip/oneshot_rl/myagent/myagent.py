"""
**Submitted to ANAC 2024 SCML (OneShot track)**
*Team* type your team name here
*Authors* type your team member names with their emails here

This code is free to use or update given that proper attribution is given to
the authors and the ANAC 2024 SCML competition.
"""
import time

from negmas.helpers import humanize_time
from scml.oneshot.agents import GreedyOneShotAgent, SyncRandomOneShotAgent
from scml.oneshot.rl.agent import OneShotRLAgent
from scml.oneshot.rl.common import model_wrapper
from scml.utils import anac2023_oneshot
from tabulate import tabulate

# import sys
# from pathlib import Path
# sys.path.append(str(Path(__file__).parent))
from .common import MODEL_PATH, MyObservationManager, TrainingAlgorithm, make_factory

# used to repeat the response to every negotiator.


class MyAgent(OneShotRLAgent):
    """
    This is the only class you *need* to implement. The current skeleton simply loads a single model
    that is supposed to be saved in MODEL_PATH (train.py can be used to train such a model).
    """

    def __init__(self, *args, **kwargs):
        # get full path to models (supplier and consumer models).
        base_name = MODEL_PATH.name
        paths = [
            MODEL_PATH.parent / f"{base_name}_supplier",
            MODEL_PATH.parent / f"{base_name}_consumer",
        ]
        # update keyword arguments
        kwargs.update(
            dict(
                # load models from MODEL_PATH
                models=tuple(model_wrapper(TrainingAlgorithm.load(_)) for _ in paths),
                # create corresponding observation managers
                observation_managers=(
                    MyObservationManager(factory=make_factory(as_supplier=True)),
                    MyObservationManager(factory=make_factory(as_supplier=False)),
                ),
            )
        )
        # Initialize the base OneShotRLAgent with model paths and observation managers.
        super().__init__(*args, **kwargs)


def run(
    n_steps=10,
    n_configs=2,
    debug=False,
):
    """
    **Not needed for submission.** You can use this function to test your agent.

    Args:
        n_steps:     The number of simulation steps.
        n_configs:   Number of different world configurations to try.
                     Different world configurations will correspond to
                     different number of factories, profiles
                     , production graphs etc

    Returns:
        None

    Remarks:

        - This function will take several minutes to run.
        - To speed it up, use a smaller `n_step` value

    """
    competitors = [MyAgent, GreedyOneShotAgent, SyncRandomOneShotAgent]

    start = time.perf_counter()
    results = anac2023_oneshot(
        competitors=competitors,
        verbose=True,
        n_steps=n_steps,
        n_configs=n_configs,
        parallelism="serial" if debug else "parallel",
    )
    # just make names shorter
    results.total_scores.agent_type = results.total_scores.agent_type.str.split(  # type: ignore
        "."
    ).str[
        -1
    ]
    # display results
    print(tabulate(results.total_scores, headers="keys", tablefmt="psql"))  # type: ignore
    print(f"Finished in {humanize_time(time.perf_counter() - start)}")


if __name__ == "__main__":
    run()
