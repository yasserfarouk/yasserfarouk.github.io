#!/bin/sh

docker compose run --service-ports anl $@
